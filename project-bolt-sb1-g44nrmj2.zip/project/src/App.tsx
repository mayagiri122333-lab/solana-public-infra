import { Github, Zap, Shield, Users, Code, TrendingUp, CheckCircle, Rocket, Globe, Lock, BookOpen, GitBranch } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md z-50 border-b border-purple-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-green-400 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-black" />
              </div>
              <span className="text-xl font-bold">SPIT</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#problem" className="hover:text-purple-400 transition">Problem</a>
              <a href="#solution" className="hover:text-purple-400 transition">Solution</a>
              <a href="#roadmap" className="hover:text-purple-400 transition">Roadmap</a>
              <a href="#grant" className="hover:text-purple-400 transition">Grant Alignment</a>
            </div>
          </div>
        </div>
      </nav>

      <HeroSection />
      <ProblemSection />
      <SolutionSection />
      <WhyItMattersSection />
      <OpenSourceSection />
      <RoadmapSection />
      <TeamSection />
      <GrantAlignmentSection />
      <TechStackSection />
      <TrustSection />
      <Footer />
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 px-4 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-green-900/20" />
      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(138, 43, 226, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(34, 197, 94, 0.15) 0%, transparent 50%)'
      }} />

      <div className="relative max-w-6xl mx-auto text-center">
        <div className="inline-block mb-6">
          <span className="px-4 py-2 bg-purple-500/10 border border-purple-500/30 rounded-full text-purple-300 text-sm font-medium">
            Open-Source Public Good • Solana Native
          </span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          <span className="bg-gradient-to-r from-purple-400 via-green-300 to-purple-400 bg-clip-text text-transparent">
            Solana Public Infra Toolkit
          </span>
        </h1>

        <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
          Open-source developer tools, SDKs, and dashboards that make building on Solana
          <span className="text-green-400 font-semibold"> easier, cheaper, and safer</span>
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a href="#roadmap" className="px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 rounded-lg font-semibold transition-all transform hover:scale-105 flex items-center space-x-2">
            <Rocket className="w-5 h-5" />
            <span>View Open-Source Roadmap</span>
          </a>
          <a href="#grant" className="px-8 py-4 bg-green-600/20 hover:bg-green-600/30 border-2 border-green-500 rounded-lg font-semibold transition-all flex items-center space-x-2">
            <CheckCircle className="w-5 h-5" />
            <span>Grant Alignment Details</span>
          </a>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
          {[
            { label: 'Open Source', icon: Github },
            { label: 'Non-Extractive', icon: Shield },
            { label: 'Community-Driven', icon: Users },
            { label: 'Solana-Native', icon: Zap }
          ].map((item) => (
            <div key={item.label} className="text-center">
              <item.icon className="w-8 h-8 mx-auto mb-2 text-purple-400" />
              <p className="text-sm text-gray-400">{item.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProblemSection() {
  return (
    <section id="problem" className="py-20 px-4 bg-gradient-to-b from-black to-purple-950/20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            The <span className="text-red-400">Problem</span> Solana Builders Face
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Despite Solana's performance advantages, developers encounter significant infrastructure barriers
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              title: 'Fragmented Tooling',
              description: 'Developers cobble together disparate tools, SDKs, and libraries with inconsistent APIs and documentation.',
              icon: Code,
              color: 'red'
            },
            {
              title: 'High Infrastructure Costs',
              description: 'RPC node expenses and monitoring tools can cost thousands monthly, especially for new teams.',
              icon: TrendingUp,
              color: 'orange'
            },
            {
              title: 'Lack of Transparency',
              description: 'No unified way to monitor network health, transaction costs, or ecosystem metrics in real-time.',
              icon: Globe,
              color: 'yellow'
            }
          ].map((problem) => (
            <div key={problem.title} className="bg-gradient-to-br from-gray-900 to-gray-800 border border-gray-700 rounded-xl p-6 hover:border-purple-500/50 transition-all">
              <div className={`w-12 h-12 bg-${problem.color}-500/10 rounded-lg flex items-center justify-center mb-4`}>
                <problem.icon className={`w-6 h-6 text-${problem.color}-400`} />
              </div>
              <h3 className="text-xl font-bold mb-3">{problem.title}</h3>
              <p className="text-gray-400 leading-relaxed">{problem.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-red-500/5 border border-red-500/20 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-4 text-red-300">The Result?</h3>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start space-x-3">
              <span className="text-red-400 font-bold">•</span>
              <span>Increased developer churn as teams struggle with infrastructure complexity</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-red-400 font-bold">•</span>
              <span>Slower ecosystem growth compared to competing chains with better tooling</span>
            </li>
            <li className="flex items-start space-x-3">
              <span className="text-red-400 font-bold">•</span>
              <span>Centralization risks as teams rely on expensive proprietary solutions</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}

function SolutionSection() {
  return (
    <section id="solution" className="py-20 px-4 bg-gradient-to-b from-purple-950/20 to-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            The <span className="text-green-400">Solution</span>: SPIT
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A unified, open-source toolkit that solves infrastructure challenges for the entire Solana ecosystem
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {[
            {
              title: 'Modular SDKs',
              description: 'Type-safe, well-documented libraries for common Solana operations. Drop into any project instantly.',
              features: ['Transaction builders', 'Account parsing', 'RPC optimization'],
              icon: Code
            },
            {
              title: 'Plug-and-Play Dashboards',
              description: 'Pre-built monitoring interfaces for network health, transaction analytics, and cost tracking.',
              features: ['Real-time metrics', 'Historical data', 'Custom alerts'],
              icon: TrendingUp
            },
            {
              title: 'Open Analytics APIs',
              description: 'Public endpoints for ecosystem data. No vendor lock-in, no usage limits for builders.',
              features: ['RESTful APIs', 'WebSocket feeds', 'GraphQL queries'],
              icon: Globe
            }
          ].map((solution) => (
            <div key={solution.title} className="bg-gradient-to-br from-green-900/20 to-purple-900/20 border border-green-500/30 rounded-xl p-6 hover:border-green-400 transition-all">
              <solution.icon className="w-10 h-10 text-green-400 mb-4" />
              <h3 className="text-2xl font-bold mb-3 text-green-300">{solution.title}</h3>
              <p className="text-gray-300 mb-4 leading-relaxed">{solution.description}</p>
              <ul className="space-y-2">
                {solution.features.map((feature) => (
                  <li key={feature} className="flex items-center space-x-2 text-sm text-gray-400">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-purple-900/30 to-green-900/30 border border-purple-500/30 rounded-2xl p-8">
          <h3 className="text-2xl font-bold mb-6 text-center">Architecture Overview</h3>
          <div className="grid md:grid-cols-5 gap-4 items-center">
            {['Developer Apps', 'SPIT SDK', 'Core APIs', 'Analytics Layer', 'Solana Network'].map((layer, idx) => (
              <div key={layer}>
                <div className="bg-gradient-to-br from-purple-600 to-green-600 rounded-lg p-4 text-center font-semibold">
                  {layer}
                </div>
                {idx < 4 && (
                  <div className="text-center text-green-400 text-2xl my-2">→</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function WhyItMattersSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-black to-purple-950/20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Why This Matters for <span className="text-purple-400">Solana</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Public infrastructure investments create compounding returns for the entire ecosystem
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {[
            {
              metric: '3x',
              label: 'Faster Onboarding',
              description: 'Reduce time-to-first-app from weeks to days',
              color: 'purple'
            },
            {
              metric: '60%',
              label: 'Cost Reduction',
              description: 'Lower infrastructure costs for new teams',
              color: 'green'
            },
            {
              metric: '100%',
              label: 'Open Access',
              description: 'Free forever, no usage limits or paywalls',
              color: 'blue'
            }
          ].map((stat) => (
            <div key={stat.label} className="text-center bg-gradient-to-br from-gray-900 to-gray-800 border border-gray-700 rounded-xl p-8">
              <div className={`text-5xl font-bold mb-2 text-${stat.color}-400`}>{stat.metric}</div>
              <div className="text-xl font-semibold mb-2">{stat.label}</div>
              <p className="text-gray-400">{stat.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-purple-900/20 to-green-900/20 border border-purple-500/30 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-6">Ecosystem Impact</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                title: 'Sustainability',
                description: 'Open tooling reduces dependency on centralized, profit-driven infrastructure providers',
                icon: Globe
              },
              {
                title: 'Developer Retention',
                description: 'Lower barriers mean more builders stay and contribute long-term',
                icon: Users
              },
              {
                title: 'Decentralization',
                description: 'Transparent, community-maintained infrastructure strengthens network resilience',
                icon: Shield
              },
              {
                title: 'Innovation Velocity',
                description: 'Standard tools let teams focus on unique value instead of reinventing infrastructure',
                icon: Rocket
              }
            ].map((impact) => (
              <div key={impact.title} className="flex space-x-4">
                <impact.icon className="w-8 h-8 text-green-400 flex-shrink-0" />
                <div>
                  <h4 className="text-lg font-semibold mb-2">{impact.title}</h4>
                  <p className="text-gray-400">{impact.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function OpenSourceSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-purple-950/20 to-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-green-400">Open-Source</span> Commitment
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            True public goods are transparent, accessible, and community-owned
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {[
            { label: 'Open Source', icon: Github, color: 'green' },
            { label: 'Public Good', icon: Users, color: 'purple' },
            { label: 'Solana Native', icon: Zap, color: 'blue' }
          ].map((badge) => (
            <div key={badge.label} className={`bg-${badge.color}-500/10 border-2 border-${badge.color}-500 rounded-xl p-6 text-center`}>
              <badge.icon className={`w-12 h-12 mx-auto mb-3 text-${badge.color}-400`} />
              <div className="text-xl font-bold">{badge.label}</div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-gray-900 to-gray-800 border border-gray-700 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-6">Our Guarantees</h3>
          <div className="space-y-4">
            {[
              {
                title: 'MIT or Apache 2.0 License',
                description: 'All code is freely available for use, modification, and distribution'
              },
              {
                title: 'Public GitHub Repository',
                description: 'Complete transparency with issue tracking, pull requests, and community contributions'
              },
              {
                title: 'Community-Driven Governance',
                description: 'Major decisions guided by ecosystem needs, not profit motives'
              },
              {
                title: 'No Token, No Fees',
                description: 'Zero revenue extraction. This is infrastructure, not a business.'
              }
            ].map((guarantee) => (
              <div key={guarantee.title} className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-lg font-semibold mb-1">{guarantee.title}</h4>
                  <p className="text-gray-400">{guarantee.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 text-center">
          <a href="https://github.com" className="inline-flex items-center space-x-2 px-6 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-600 rounded-lg transition">
            <Github className="w-5 h-5" />
            <span>View on GitHub (Coming Soon)</span>
          </a>
        </div>
      </div>
    </section>
  );
}

function RoadmapSection() {
  return (
    <section id="roadmap" className="py-20 px-4 bg-gradient-to-b from-black to-purple-950/20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Development <span className="text-purple-400">Roadmap</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Transparent, milestone-based delivery with clear grant fund allocation
          </p>
        </div>

        <div className="space-y-8">
          {[
            {
              phase: 'Phase 1',
              timeline: '0–3 Months',
              title: 'Core SDK Development',
              budget: '$30,000',
              deliverables: [
                'Transaction builder library with full type safety',
                'Account parsing utilities for common program types',
                'RPC optimization layer with caching and batching',
                'Comprehensive documentation and examples'
              ],
              color: 'purple'
            },
            {
              phase: 'Phase 2',
              timeline: '3–6 Months',
              title: 'Dashboard & Analytics Platform',
              budget: '$40,000',
              deliverables: [
                'Real-time network health monitoring dashboard',
                'Transaction cost analytics and visualization',
                'Public REST and WebSocket APIs',
                'Developer onboarding tutorials and guides'
              ],
              color: 'green'
            },
            {
              phase: 'Phase 3',
              timeline: '6–9 Months',
              title: 'Community Adoption & Security',
              budget: '$20,000',
              deliverables: [
                'Security audit by reputable firm',
                'Community contribution framework',
                'Integration partnerships with 5+ projects',
                'Performance benchmarks and case studies'
              ],
              color: 'blue'
            }
          ].map((phase, idx) => (
            <div key={phase.phase} className="relative">
              <div className={`bg-gradient-to-r from-${phase.color}-900/30 to-gray-900 border border-${phase.color}-500/30 rounded-xl p-8`}>
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-6">
                  <div>
                    <div className={`text-${phase.color}-400 font-semibold mb-2`}>{phase.phase} • {phase.timeline}</div>
                    <h3 className="text-2xl font-bold mb-2">{phase.title}</h3>
                    <div className="text-xl font-semibold text-green-400">{phase.budget} Grant Allocation</div>
                  </div>
                  <div className={`mt-4 md:mt-0 px-4 py-2 bg-${phase.color}-500/20 border border-${phase.color}-500 rounded-lg text-sm font-medium`}>
                    {idx === 0 ? 'Foundation' : idx === 1 ? 'Growth' : 'Sustainability'}
                  </div>
                </div>
                <h4 className="font-semibold mb-3">Key Deliverables:</h4>
                <ul className="space-y-2">
                  {phase.deliverables.map((item) => (
                    <li key={item} className="flex items-start space-x-3">
                      <CheckCircle className={`w-5 h-5 text-${phase.color}-400 flex-shrink-0 mt-0.5`} />
                      <span className="text-gray-300">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              {idx < 2 && (
                <div className="flex justify-center my-4">
                  <div className="w-0.5 h-8 bg-gradient-to-b from-purple-500 to-green-500" />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-12 bg-green-500/5 border border-green-500/20 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-4 text-green-300">Total Grant Request: $90,000</h3>
          <p className="text-gray-300 mb-4">
            Funds allocated to: development (60%), security audits (15%), documentation (15%), community initiatives (10%)
          </p>
          <p className="text-gray-400 text-sm">
            All spending tracked publicly. Unused funds returned to Solana Foundation or allocated to Phase 4 based on community feedback.
          </p>
        </div>
      </div>
    </section>
  );
}

function TeamSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-purple-950/20 to-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            The <span className="text-purple-400">Team</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Small, focused, and committed to long-term ecosystem value
          </p>
        </div>

        <div className="bg-gradient-to-br from-gray-900 to-gray-800 border border-gray-700 rounded-xl p-8">
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
            <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-green-400 rounded-full flex items-center justify-center text-4xl font-bold">
              OS
            </div>
            <div className="flex-1 text-center md:text-left">
              <h3 className="text-2xl font-bold mb-2">Open-Source Collective</h3>
              <p className="text-purple-400 mb-4">Core Maintainers & Community Contributors</p>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Led by experienced Solana developers with backgrounds in infrastructure, developer tooling, and open-source maintenance.
                No company entity required—this is a public goods project maintained by builders, for builders.
              </p>
              <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                {['Rust', 'Solana', 'TypeScript', 'Open Source', 'DevRel'].map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-purple-500/20 border border-purple-500/30 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {[
            {
              title: 'Long-Term Commitment',
              description: 'Not a startup. Not seeking profit. Dedicated to maintaining this infrastructure for years.',
              icon: Shield
            },
            {
              title: 'Proven Track Record',
              description: 'Core team has contributed to major Solana projects and understands ecosystem needs deeply.',
              icon: CheckCircle
            },
            {
              title: 'Community First',
              description: 'Decisions guided by developer feedback, not investor returns or quarterly targets.',
              icon: Users
            }
          ].map((value) => (
            <div key={value.title} className="bg-gray-900/50 border border-gray-700 rounded-lg p-6">
              <value.icon className="w-8 h-8 text-green-400 mb-3" />
              <h4 className="text-lg font-semibold mb-2">{value.title}</h4>
              <p className="text-gray-400 text-sm">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function GrantAlignmentSection() {
  return (
    <section id="grant" className="py-20 px-4 bg-gradient-to-b from-black to-green-950/20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-green-400">Grant Alignment</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            This project embodies the Solana Foundation's mission to support genuine public goods
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-900/20 to-purple-900/20 border-2 border-green-500 rounded-2xl p-8 md:p-12 mb-12">
          <h3 className="text-3xl font-bold mb-8 text-center">Why SPIT Qualifies as a Public Good</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Non-Rivalrous',
                description: 'One developer using SPIT does not prevent others from using it. Infinite scalability.',
                icon: Users
              },
              {
                title: 'Non-Excludable',
                description: 'No paywalls, no API limits, no premium tiers. Available to everyone forever.',
                icon: Globe
              },
              {
                title: 'Zero Revenue Model',
                description: 'No token launch, no subscriptions, no data monetization. Pure infrastructure.',
                icon: Shield
              },
              {
                title: 'Ecosystem-Wide Benefit',
                description: 'Improvements help all Solana builders, from hobbyists to enterprises.',
                icon: Rocket
              }
            ].map((criterion) => (
              <div key={criterion.title} className="flex space-x-4">
                <criterion.icon className="w-10 h-10 text-green-400 flex-shrink-0" />
                <div>
                  <h4 className="text-xl font-bold mb-2 text-green-300">{criterion.title}</h4>
                  <p className="text-gray-300">{criterion.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-gray-900 border border-purple-500/30 rounded-xl p-8">
            <h3 className="text-2xl font-bold mb-6 text-purple-400">Alignment with Foundation Goals</h3>
            <ul className="space-y-4">
              {[
                'Reducing barriers to entry for new developers',
                'Strengthening network decentralization through open tools',
                'Fostering long-term ecosystem sustainability',
                'Supporting community-driven innovation'
              ].map((goal) => (
                <li key={goal} className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">{goal}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-gray-900 border border-green-500/30 rounded-xl p-8">
            <h3 className="text-2xl font-bold mb-6 text-green-400">What This Is NOT</h3>
            <ul className="space-y-4">
              {[
                'A for-profit company seeking product-market fit',
                'A token launch masquerading as infrastructure',
                'A proprietary platform with vendor lock-in',
                'A short-term project abandoned after funding'
              ].map((anti) => (
                <li key={anti} className="flex items-start space-x-3">
                  <span className="text-red-400 text-xl flex-shrink-0">✗</span>
                  <span className="text-gray-300">{anti}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 bg-gradient-to-r from-purple-900/30 to-green-900/30 border border-green-500/30 rounded-xl p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Long-Term Sustainability</h3>
          <p className="text-gray-300 max-w-3xl mx-auto leading-relaxed">
            After initial grant funding, SPIT will sustain through volunteer contributions, potential follow-up grants for major features,
            and community maintenance—similar to other successful open-source infrastructure projects.
            No business model needed because this is infrastructure, not a product.
          </p>
        </div>
      </div>
    </section>
  );
}

function TechStackSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-green-950/20 to-black">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Technical <span className="text-purple-400">Stack</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Built with battle-tested technologies from the Solana ecosystem
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {[
            { name: 'Solana', color: 'purple' },
            { name: 'Rust', color: 'orange' },
            { name: 'TypeScript', color: 'blue' },
            { name: 'Web3.js', color: 'green' },
            { name: 'Anchor', color: 'purple' }
          ].map((tech) => (
            <div key={tech.name} className={`bg-gradient-to-br from-${tech.color}-900/20 to-gray-900 border border-${tech.color}-500/30 rounded-xl p-6 text-center hover:border-${tech.color}-400 transition-all`}>
              <Code className={`w-10 h-10 mx-auto mb-3 text-${tech.color}-400`} />
              <div className="font-semibold">{tech.name}</div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-gray-900 border border-gray-700 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-6">Architecture Principles</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              'Modular design for easy integration',
              'Zero external dependencies where possible',
              'Performance-first implementation',
              'Comprehensive error handling',
              'Full TypeScript support',
              'Extensive test coverage'
            ].map((principle) => (
              <div key={principle} className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-purple-400" />
                <span className="text-gray-300">{principle}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-black to-purple-950/20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Trust & <span className="text-green-400">Transparency</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Security and accountability built into every aspect
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              title: 'Security-First Mindset',
              description: 'All code reviewed, tested, and audited before production use',
              icon: Lock
            },
            {
              title: 'Public Reporting',
              description: 'Monthly progress updates, financial transparency, and open roadmap adjustments',
              icon: BookOpen
            },
            {
              title: 'Community Oversight',
              description: 'Major decisions require public discussion and consensus from active contributors',
              icon: Users
            }
          ].map((item) => (
            <div key={item.title} className="bg-gradient-to-br from-gray-900 to-gray-800 border border-gray-700 rounded-xl p-6">
              <item.icon className="w-10 h-10 text-green-400 mb-4" />
              <h3 className="text-xl font-bold mb-3">{item.title}</h3>
              <p className="text-gray-400">{item.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-green-500/5 border border-green-500/20 rounded-xl p-8">
          <h3 className="text-2xl font-bold mb-4 text-green-300">Audit Commitment</h3>
          <p className="text-gray-300 mb-4">
            Phase 3 includes comprehensive security audit by a reputable firm (Trail of Bits, Quantstamp, or equivalent).
            All audit reports published publicly.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center space-x-2 text-sm">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>Code audit planned</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>Public vulnerability disclosure</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>Bug bounty program</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-black border-t border-purple-900/30 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-green-400 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-black" />
            </div>
            <div>
              <div className="font-bold text-lg">Solana Public Infra Toolkit</div>
              <div className="text-sm text-gray-400">Open-Source • Public Good • Solana-Native</div>
            </div>
          </div>

          <div className="flex space-x-6">
            <a href="https://github.com" className="text-gray-400 hover:text-white transition">
              <Github className="w-6 h-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition">
              <GitBranch className="w-6 h-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition">
              <BookOpen className="w-6 h-6" />
            </a>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>Built for the Solana ecosystem. Licensed under MIT. No tokens, no fees, no extraction.</p>
          <p className="mt-2">Seeking Solana Foundation grant support to accelerate public goods development.</p>
        </div>
      </div>
    </footer>
  );
}

export default App;
